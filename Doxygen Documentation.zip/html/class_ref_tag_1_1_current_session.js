var class_ref_tag_1_1_current_session =
[
    [ "CurrentSession", "class_ref_tag_1_1_current_session.html#aa8996aea9513847b67ea777f50277871", null ],
    [ "AddTag", "class_ref_tag_1_1_current_session.html#a16ecef46e534c0ab094812c610bf1dc8", null ],
    [ "NewTag", "class_ref_tag_1_1_current_session.html#a845699878f1c819595d398490e10a26c", null ],
    [ "NewTag", "class_ref_tag_1_1_current_session.html#a16478c60150632a0bb9b80a69540b3ad", null ],
    [ "RemoveTag", "class_ref_tag_1_1_current_session.html#ad760325a07331e333bc358bfbde5eb0e", null ],
    [ "SetOpenedTag", "class_ref_tag_1_1_current_session.html#a06b0143d88258f93597c253a84050cef", null ],
    [ "OpenedTag", "class_ref_tag_1_1_current_session.html#a66881cfc4df701d2254654cbedf7416b", null ],
    [ "Tags", "class_ref_tag_1_1_current_session.html#a088509e36530632a7a708116068a44c8", null ]
];
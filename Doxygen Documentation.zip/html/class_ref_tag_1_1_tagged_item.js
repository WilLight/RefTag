var class_ref_tag_1_1_tagged_item =
[
    [ "TaggedItem", "class_ref_tag_1_1_tagged_item.html#a3650bb43fe8d8e22a79888559dea070b", null ],
    [ "ItemCreationDate", "class_ref_tag_1_1_tagged_item.html#ad170c97ca2f621418e5ef079b84a16d8", null ],
    [ "ItemFileExtension", "class_ref_tag_1_1_tagged_item.html#a3458ac43b9638f4b914036440f1886ae", null ],
    [ "ItemModificationDate", "class_ref_tag_1_1_tagged_item.html#a3753b00019a2309610112dcbf78d6d6e", null ],
    [ "ItemName", "class_ref_tag_1_1_tagged_item.html#a2f579bbcc736ce7f9bb8e66d4d3f24d1", null ],
    [ "ItemPath", "class_ref_tag_1_1_tagged_item.html#ab05d7b027c41604cf5d944ab09009a8b", null ]
];
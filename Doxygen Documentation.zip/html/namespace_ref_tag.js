var namespace_ref_tag =
[
    [ "CurrentSession", "class_ref_tag_1_1_current_session.html", "class_ref_tag_1_1_current_session" ],
    [ "Form1", "class_ref_tag_1_1_form1.html", "class_ref_tag_1_1_form1" ],
    [ "JsonSerialization", "class_ref_tag_1_1_json_serialization.html", "class_ref_tag_1_1_json_serialization" ],
    [ "PopupWindows", "class_ref_tag_1_1_popup_windows.html", "class_ref_tag_1_1_popup_windows" ],
    [ "Program", "class_ref_tag_1_1_program.html", null ],
    [ "Tag", "class_ref_tag_1_1_tag.html", "class_ref_tag_1_1_tag" ],
    [ "TaggedItem", "class_ref_tag_1_1_tagged_item.html", "class_ref_tag_1_1_tagged_item" ]
];
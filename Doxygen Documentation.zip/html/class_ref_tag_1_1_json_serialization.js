var class_ref_tag_1_1_json_serialization =
[
    [ "ReadFromJsonFile< T >", "class_ref_tag_1_1_json_serialization.html#ab0e79cd0749297a9be20fa1b52e03663", null ],
    [ "WriteToJsonFile< T >", "class_ref_tag_1_1_json_serialization.html#ac9e331a0dbf35e9b65bbe6440d98c546", null ]
];
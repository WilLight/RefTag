var searchData=
[
  ['writetojsonfile_3c_20t_20_3e_33',['WriteToJsonFile&lt; T &gt;',['../class_ref_tag_1_1_json_serialization.html#ac9e331a0dbf35e9b65bbe6440d98c546',1,'RefTag::JsonSerialization']]]
];

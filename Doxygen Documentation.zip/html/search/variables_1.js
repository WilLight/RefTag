var searchData=
[
  ['isfolder_62',['IsFolder',['../class_ref_tag_1_1_tag.html#ac584f4e10add1da9c8d1280c77074981',1,'RefTag::Tag']]],
  ['itemcreationdate_63',['ItemCreationDate',['../class_ref_tag_1_1_tagged_item.html#ad170c97ca2f621418e5ef079b84a16d8',1,'RefTag::TaggedItem']]],
  ['itemfileextension_64',['ItemFileExtension',['../class_ref_tag_1_1_tagged_item.html#a3458ac43b9638f4b914036440f1886ae',1,'RefTag::TaggedItem']]],
  ['itemlist_65',['ItemList',['../class_ref_tag_1_1_tag.html#a324a5a85c53981aefb9e48a6569ff5c0',1,'RefTag::Tag']]],
  ['itemmodificationdate_66',['ItemModificationDate',['../class_ref_tag_1_1_tagged_item.html#a3753b00019a2309610112dcbf78d6d6e',1,'RefTag::TaggedItem']]],
  ['itemname_67',['ItemName',['../class_ref_tag_1_1_tagged_item.html#a2f579bbcc736ce7f9bb8e66d4d3f24d1',1,'RefTag::TaggedItem']]],
  ['itempath_68',['ItemPath',['../class_ref_tag_1_1_tagged_item.html#ab05d7b027c41604cf5d944ab09009a8b',1,'RefTag::TaggedItem']]]
];

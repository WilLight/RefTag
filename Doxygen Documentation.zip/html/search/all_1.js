var searchData=
[
  ['currentsession_2',['CurrentSession',['../class_ref_tag_1_1_current_session.html',1,'RefTag.CurrentSession'],['../class_ref_tag_1_1_current_session.html#aa8996aea9513847b67ea777f50277871',1,'RefTag.CurrentSession.CurrentSession()']]]
];

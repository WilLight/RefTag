var searchData=
[
  ['tag_39',['Tag',['../class_ref_tag_1_1_tag.html',1,'RefTag']]],
  ['taggeditem_40',['TaggedItem',['../class_ref_tag_1_1_tagged_item.html',1,'RefTag']]]
];

var searchData=
[
  ['jsonserialization_36',['JsonSerialization',['../class_ref_tag_1_1_json_serialization.html',1,'RefTag']]]
];

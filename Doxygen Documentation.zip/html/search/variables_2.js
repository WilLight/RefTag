var searchData=
[
  ['openedtag_69',['OpenedTag',['../class_ref_tag_1_1_current_session.html#a66881cfc4df701d2254654cbedf7416b',1,'RefTag::CurrentSession']]]
];

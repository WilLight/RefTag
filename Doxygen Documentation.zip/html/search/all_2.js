var searchData=
[
  ['dispose_3',['Dispose',['../class_ref_tag_1_1_form1.html#a55ced2f6a8126831c96c42052d434a8c',1,'RefTag::Form1']]]
];

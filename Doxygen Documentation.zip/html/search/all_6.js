var searchData=
[
  ['newtag_16',['NewTag',['../class_ref_tag_1_1_current_session.html#a845699878f1c819595d398490e10a26c',1,'RefTag.CurrentSession.NewTag(string tagName)'],['../class_ref_tag_1_1_current_session.html#a16478c60150632a0bb9b80a69540b3ad',1,'RefTag.CurrentSession.NewTag(string tagName, string folderPath)']]]
];

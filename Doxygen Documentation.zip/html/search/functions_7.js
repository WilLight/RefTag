var searchData=
[
  ['tag_58',['Tag',['../class_ref_tag_1_1_tag.html#ab41271aa807d7c6099a72d2a7bb4a705',1,'RefTag.Tag.Tag()'],['../class_ref_tag_1_1_tag.html#ac64079ac60a153f2bb31af8459f2b68b',1,'RefTag.Tag.Tag(string tagName)'],['../class_ref_tag_1_1_tag.html#a0c460f3fc96bba0afdfebbb486f215f0',1,'RefTag.Tag.Tag(string tagName, string folderPath)']]],
  ['taggeditem_59',['TaggedItem',['../class_ref_tag_1_1_tagged_item.html#a3650bb43fe8d8e22a79888559dea070b',1,'RefTag::TaggedItem']]]
];

var searchData=
[
  ['currentsession_34',['CurrentSession',['../class_ref_tag_1_1_current_session.html',1,'RefTag']]]
];

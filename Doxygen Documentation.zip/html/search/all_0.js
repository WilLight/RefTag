var searchData=
[
  ['addtag_0',['AddTag',['../class_ref_tag_1_1_current_session.html#a16ecef46e534c0ab094812c610bf1dc8',1,'RefTag::CurrentSession']]],
  ['addtotag_1',['AddToTag',['../class_ref_tag_1_1_tag.html#a2122640030fd1de617b4af4ccd859c88',1,'RefTag.Tag.AddToTag(TaggedItem item)'],['../class_ref_tag_1_1_tag.html#af8c426d43954e47ed88e02e6e138dd72',1,'RefTag.Tag.AddToTag(TaggedItem[] items)'],['../class_ref_tag_1_1_tag.html#a6d229dffb854604d0073c57e155b779b',1,'RefTag.Tag.AddToTag(List&lt; TaggedItem &gt; items)']]]
];

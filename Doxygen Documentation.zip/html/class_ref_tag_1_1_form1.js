var class_ref_tag_1_1_form1 =
[
    [ "Form1", "class_ref_tag_1_1_form1.html#a291c08c178c75ef1f000b87f8a26ad73", null ],
    [ "Dispose", "class_ref_tag_1_1_form1.html#a55ced2f6a8126831c96c42052d434a8c", null ]
];
var class_ref_tag_1_1_popup_windows =
[
    [ "ShowContextMenu", "class_ref_tag_1_1_popup_windows.html#a28255de220f96712cc9c24b16518dcc1", null ],
    [ "ShowContextMenu", "class_ref_tag_1_1_popup_windows.html#a530b218bef4f030a5bb0556e5cd9c40e", null ],
    [ "ShowDuplicateWarning", "class_ref_tag_1_1_popup_windows.html#af8e847ad40d5c011f1b500aed2541ca6", null ],
    [ "ShowTextInputDialog", "class_ref_tag_1_1_popup_windows.html#a663b5a677fa1c871a7152d3ee81f11a1", null ]
];
var hierarchy =
[
    [ "RefTag.CurrentSession", "class_ref_tag_1_1_current_session.html", null ],
    [ "Form", null, [
      [ "RefTag.Form1", "class_ref_tag_1_1_form1.html", null ]
    ] ],
    [ "RefTag.JsonSerialization", "class_ref_tag_1_1_json_serialization.html", null ],
    [ "RefTag.PopupWindows", "class_ref_tag_1_1_popup_windows.html", null ],
    [ "RefTag.Program", "class_ref_tag_1_1_program.html", null ],
    [ "RefTag.Tag", "class_ref_tag_1_1_tag.html", null ],
    [ "RefTag.TaggedItem", "class_ref_tag_1_1_tagged_item.html", null ]
];
var dir_bcc0d32dc59a1945b5ba4a8aa4ef8cb0 =
[
    [ "Form1.cs", "_form1_8cs.html", [
      [ "Form1", "class_ref_tag_1_1_form1.html", "class_ref_tag_1_1_form1" ],
      [ "CurrentSession", "class_ref_tag_1_1_current_session.html", "class_ref_tag_1_1_current_session" ],
      [ "Tag", "class_ref_tag_1_1_tag.html", "class_ref_tag_1_1_tag" ],
      [ "TaggedItem", "class_ref_tag_1_1_tagged_item.html", "class_ref_tag_1_1_tagged_item" ],
      [ "PopupWindows", "class_ref_tag_1_1_popup_windows.html", "class_ref_tag_1_1_popup_windows" ],
      [ "JsonSerialization", "class_ref_tag_1_1_json_serialization.html", "class_ref_tag_1_1_json_serialization" ]
    ] ],
    [ "Form1.Designer.cs", "_form1_8_designer_8cs.html", [
      [ "Form1", "class_ref_tag_1_1_form1.html", "class_ref_tag_1_1_form1" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", [
      [ "Program", "class_ref_tag_1_1_program.html", null ]
    ] ]
];